package app.taptik.video.downloader.videodownloader.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnOpen).setOnClickListener(v -> {
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(MainActivity.this, ConfigNotification.CHANNEL_ID);
            // chanelID : phân luồng thông báo :
            // ví du: nếu có 5 thông báo cùng channelID thì thay vì hiển thị hết 5 thông báo nó sẽ t
            // thay bằng 1 thông báo với số đi kèm +1 , +2 , +3 ....
            builder.setSmallIcon(R.drawable.ic_launcher_background);
            builder.setContentTitle("Thong bao!!!");
            builder.setContentText("Vui long thanh toan tien dien....");

            Bitmap logo = BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher_background);
            builder.setStyle(new NotificationCompat.BigPictureStyle().bigLargeIcon(logo).bigLargeIcon(null));

            NotificationManagerCompat com = NotificationManagerCompat.from(this);
            // xin quyen tu phía người dùng để hiển thị thông báo
            // kiểm tra xem có quyền chưa
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED
            ) {
                com.notify((int) new Date().getTime(), builder.build());
            } else {
                // xin quyen
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        999); // 999  là mã tuỳ ý để nhận biết sự kiện người dùng đồng ý hay từ chối
            }

        });
    }
}